<footer>
    <hr>
        <div class="text-center center-block">
            <p class="txt-railway">&copy GameHub</p>
            <br />
            <a href="#"><img src="https://s3.amazonaws.com/codecademy-content/projects/make-a-website/lesson-4/twitter.svg" width:"30px" height="30px"></a>
            <a href="#"><img src="https://s3.amazonaws.com/codecademy-content/projects/make-a-website/lesson-4/facebook.svg" width:"30px" height="30px"></a>
            <a href="#"><img src="https://s3.amazonaws.com/codecademy-content/projects/make-a-website/lesson-4/instagram.svg" width:"30px" height="30px"></a>
        </div>
    <hr>
<footer>