<!DOCTYPE html>
<html>
<head>
	<title>search</title>
</head>
<body>
<form action="search.php" method="GET">
	<input type="text" name="query" placeholder="search">
	<input type="submit" name="submit" value="Search">
	
</form>
</body>
</html>